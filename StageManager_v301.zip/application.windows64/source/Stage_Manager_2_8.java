import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.*; 
import java.util.*; 
import java.nio.channels.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Stage_Manager_2_8 extends PApplet {






//Font
static int textHeight;
static PFont font;

//Margins
int xMargin;
int yMargin;

//Rehearsal number
static int currentRehearsal;

Script script;

public void set_script_null()
{
  println("Exiting...");
  script = null;
  check_files();
}

ArrayList<String> Scripts = new ArrayList<String>();

int scroll_pos = 0;
PVector menu_pos_min;
PVector menu_pos_max;
PVector new_script_btn_min;
PVector new_script_btn_max;
String script_file_prefix = "";

public void setup()
{
  //Set the screen size to full screen
  size(displayWidth, displayHeight);

  menu_pos_min = new PVector(100, 100);
  menu_pos_max = new PVector(width-50, height-50);
  new_script_btn_min = new PVector(10, 100);
  new_script_btn_max = new PVector(90, height-10);
  //Font
  textHeight = 20;
  font = createFont("Arial", textHeight, true);
  textFont(font);
  //Margins
  xMargin = 20;
  yMargin = 20;
  check_files();
}

public void check_files()
{
  Scripts.clear();
  File dir = new File(dataPath("scripts/"));
  File[] files = dir.listFiles();
  if (files != null)
  {
    for (File f : files)
    {
      if (f.isDirectory())
      {
        Scripts.add(f.getName());
      }
    }
  } else
  {
    dir.mkdirs();
  }
}

public void draw()
{
  if (script == null)
  {
    select_script();
  } else
  {
    script.draw();
  }
}


public void select_script()
{
  background(0, 0, 50);
  if (Scripts.size() > 0)
  {
    int i = scroll_pos;
    noStroke();
    for (String f : Scripts)
    {
      if (menu_pos_min.x < mouseX && mouseX < menu_pos_max.x &&
        mouseY > menu_pos_min.y - i*32 && mouseY < menu_pos_min.y - i*32 + 30 &&
        mouseY > menu_pos_min.y && mouseY < menu_pos_max.y)
      {
        fill(200, 150);
      } else
      {
        fill(150, 100);
      }
      rect(menu_pos_min.x, menu_pos_min.y-32*i, menu_pos_max.x-menu_pos_min.x, 31);
      text(f, menu_pos_min.x + 10, menu_pos_min.y-32*i + 24);
      i += 32;
    }
    //rect(menu_pos_min.x, menu_pos_min.y+32*i, menu_pos_max.x-menu_pos_min.x, 30);
    fill(0, 0, 50);
    rect(menu_pos_min.x, 0, menu_pos_max.x-menu_pos_min.x, menu_pos_min.y);
    rect(menu_pos_min.x, menu_pos_max.y, menu_pos_max.x-menu_pos_min.x, height-menu_pos_max.y);

    if (new_script_btn_min.x < mouseX && mouseX < new_script_btn_max.x && 
      new_script_btn_min.y < mouseY && mouseY < new_script_btn_max.y)
    {
      fill(200, 150);
    } else
    {
      fill(150, 100);
    }
    rect(new_script_btn_min.x, new_script_btn_min.y, new_script_btn_max.x - new_script_btn_min.x, new_script_btn_max.y - new_script_btn_min.y);
    text("A\nd\nd\n \na\n \nN\ne\nw\n \nS\nc\nr\ni\np\nt", new_script_btn_min.x + 20, new_script_btn_min.y + 32);
  } else
  {
    if (menu_pos_min.x < mouseX && mouseX < menu_pos_max.x && menu_pos_min.y < mouseY && mouseY < menu_pos_max.y)
    {
      fill(200, 150);
    } else
    {
      fill(150, 100);
    }
    rect(menu_pos_min.x, menu_pos_min.y, menu_pos_max.x-menu_pos_min.x, menu_pos_max.y-menu_pos_min.y);
    text("No Scripts found...\nClick to load a new script.", menu_pos_min.x+20, menu_pos_min.y+20, menu_pos_max.x-menu_pos_min.x, menu_pos_max.y-menu_pos_min.y);
  }
}

public void file_selected(File f)
{
  if (f == null)
  {
    return;
  } else
  {
    println(f.getName());
    String filename = f.getName().replaceFirst("[.][^.]+$", "");
    File dir = new File(dataPath("scripts/"+filename+"/script.txt"));
    new File(dataPath("scripts/"+filename+"/")).mkdirs();
    try 
    {
      copyDirectory(f, dir);
      println("Copied script");
      mkFile(dataPath("scripts/"+filename+"/actors.txt"));
      mkFile(dataPath("scripts/"+filename+"/lines.txt"));
      mkFile(dataPath("scripts/"+filename+"/NOTES.txt"));
      mkFile(dataPath("scripts/"+filename+"/pages.txt"));
    } 
    catch (IOException e) 
    {
      println(e);
    }
    check_files();
  }
}

public File mkFile(String path) throws IOException
{
  File dir = new File(path.replaceFirst("[/\\\\][^/\\\\]+$", ""));
  dir.mkdirs();
  File t = new File(path);
  t.createNewFile();
  return t;
}

public void mousePressed()
{
  if (script != null)
  {
    script.mousePressed();
  } else
  {
    if (Scripts.size() > 0)
    {
      int i = scroll_pos;
      noStroke();
      for (String f : Scripts)
      {
        if (menu_pos_min.x < mouseX && mouseX < menu_pos_max.x &&
          mouseY > menu_pos_min.y - i*32 && mouseY < menu_pos_min.y - i*32 + 30 &&
          mouseY > menu_pos_min.y && mouseY < menu_pos_max.y)
        {
          script = new Script(dataPath("scripts/"+f));
        }
        i += 32;
      }
      if (new_script_btn_min.x < mouseX && mouseX < new_script_btn_max.x && 
          new_script_btn_min.y < mouseY && mouseY < new_script_btn_max.y)
      {
        selectInput("Select a script", "file_selected");
      }
    } else
    {
      if (menu_pos_min.x < mouseX && mouseX < menu_pos_max.x && menu_pos_min.y < mouseY && mouseY < menu_pos_max.y)
      {
        selectInput("Select a script", "file_selected");
      }
    }
  }
}

public void mouseDragged()
{
  if (script != null)
  {
    script.mouseDragged();
  }
}

public void mouseReleased()
{
  if (script != null)
  {
    script.mouseReleased();
  }
}

public void keyPressed()
{
  if (script != null)
  {
    script.keyPressed();
  }
}

//Set the application to be full screen
public boolean sketchFullScreen()
{
  return true;
}

public void copyDirectory(File sourceLocation, File targetLocation)
throws IOException {

  if (sourceLocation.isDirectory()) {
    if (!targetLocation.exists()) {
      targetLocation.mkdir();
    }

    String[] children = sourceLocation.list();
    for (int i=0; i<children.length; i++) {
      copyDirectory(new File(sourceLocation, children[i]), 
      new File(targetLocation, children[i]));
    }
  } else {

    InputStream in = new FileInputStream(sourceLocation);
    OutputStream out = new FileOutputStream(targetLocation);

    // Copy the bits from instream to outstream
    byte[] buf = new byte[1024];
    int len;
    while ( (len = in.read (buf)) > 0) {
      out.write(buf, 0, len);
    }
    in.close();
    out.close();
  }
}

class Actor
{
  
  //Variable declarations
  protected String charName;
  protected String actorName;
  protected ArrayList<Note> notes;
  
  //Constructor
  //Default Constructor
  Actor()
  {
    
    charName = "";
    actorName = "";
    notes = new ArrayList<Note>();
    
  }
  
  //Constructor given cName
  Actor(String c)
  {
    
    charName = c;
    actorName = "";
    notes = new ArrayList<Note>();
    
  }
  
  //Constructor given everything
  Actor(String c, String a)
  {
    
    charName = c;
    actorName = a;
    notes = new ArrayList<Note>();
    
  }
  
  //Get and set character name
  public String getCharName()
  {
    
    return charName;
    
  }
  
  public void setCharName(String c)
  {
    
    charName = c;
    
  }
  
  //Get and set actor name
  public String getActorName()
  {
    
    return actorName;
    
  }
  
  public void setActorName(String a)
  {
    
    actorName = a;
    
  }
  
  //Get and set notes
  public ArrayList<Note> getNotes()
  {
    
    return notes;
    
  }
  
  public void addNote(Note note)
  {
    
    notes.add(note);
    
  }
  
  //toString
  public String toString()
  {
    
    return(charName + " (" + actorName + ")");
    
  }
  
}
class Button
{
  
  //Variable declarations
  protected PVector topLeftPos;
  protected PVector bottomRightPos;
  protected String text;
  protected boolean typing;
  //ArrayList<Integer> states;
  
  //Constructors
  //Default Constructor
  Button()
  {
    
    topLeftPos = new PVector();
    bottomRightPos = new PVector();
    text = "";
    typing = false;
    
  }
  
  //Constructor given text
  Button(String txt)
  {
    
    topLeftPos = new PVector();
    bottomRightPos = new PVector();
    text = txt;
    typing = false;
    
  }
  
  //Constructor given 5 inputs
  Button(float px, float py, String txt, boolean t, boolean l)
  {
    
    if(t)
    {
      
      if(l)
      {
        
        topLeftPos = new PVector(px, py);
        bottomRightPos = new PVector(px + 2 * xMargin + textWidth(txt), py + 2 * yMargin + textHeight);
        
      }
      
      else
      {
        
        topLeftPos = new PVector(px - 2 * xMargin - textWidth(txt), py);
        bottomRightPos = new PVector(px, py + 2 * yMargin + textHeight);
        
      }
      
    }
    
    else
    {
      
      if(l)
      {
        
        topLeftPos = new PVector(px, py - 2 * yMargin - textHeight);
        bottomRightPos = new PVector(px + 2 * xMargin + textWidth(txt), py);
        
      }
      
      else
      {
        
        topLeftPos = new PVector(px - 2 * xMargin - textWidth(txt), py - 2 * yMargin - textHeight);
        bottomRightPos = new PVector(px, py);
        
      }
      
    }
    
    text = txt;
    typing = false;
    
  }
  
  //Display Method
  public void display()
  {
    
    rectMode(CORNERS);
    fill(153);
    noStroke();
    
    if((mouseX >= topLeftPos.x && mouseX <= bottomRightPos.x && mouseY >= topLeftPos.y && mouseY <= bottomRightPos.y) || typing)
      stroke(255);
    
    rect(topLeftPos.x, topLeftPos.y, bottomRightPos.x, bottomRightPos.y);
    fill(255);
    
    if(typing)
      fill(0, 255, 255);
    
    textAlign(LEFT, TOP);
    text(text, topLeftPos.x + xMargin, topLeftPos.y + yMargin);
    
  }
  
  //Get and set topLeftPos
  public PVector getTLP()
  {
    
    return topLeftPos;
    
  }
  
  public float getTLPx()
  {
    
    return topLeftPos.x;
    
  }
  
  public float getTLPy()
  {
    
    return topLeftPos.y;
    
  }
  
  public void setTLP(PVector tlp)
  {
    
    topLeftPos = tlp;
    
  }
  
  public void setTLP(float x, float y)
  {
    
    topLeftPos.set(x, y);
    
  }
  
  //Get and set bottomRightPos
  public PVector getBRP()
  {
    
    return bottomRightPos;
    
  }
  
  public float getBRPx()
  {
    
    return bottomRightPos.x;
    
  }
  
  public float getBRPy()
  {
    
    return bottomRightPos.y;
    
  }
  
  public void setBRP(PVector brp)
  {
    
    bottomRightPos = brp;
    
  }
  
  public void setBRP(float x, float y)
  {
    
    bottomRightPos.set(x, y);
    
  }
  
  //Get and set text
  public String getText()
  {
    
    return text;
    
  }
  
  public void setText(String t)
  {
    
    text = t;
    
  }
  
  //Get and set typing
  public boolean getTyping()
  {
    
    return typing;
    
  }
  
  public void setTyping(boolean b)
  {
    
    typing = b;
    
  }
  
}
class CallForLineNote extends Note
{
  
  //Constructors
  //Default Constructor
  CallForLineNote()
  {
    
    super();
    type = 0;
    
  }
  
  //Constructor given lines and words
  CallForLineNote(ArrayList<Line> ls, ArrayList<Word> ws)
  {
    
    super();
    lines.addAll(ls);
    words.addAll(ws);
    type = 2;
    
    for(Line line : lines)
    {
      
      if(actors.indexOf(line.getActor()) == -1)
        actors.add(line.getActor());
        
    }
    
    giveToActors();
    
  }
  
  public String toString()
  {
    String str = "CALLED FOR LINE, PAGE "+str(lines.get(0).getPage())+"\n\tLINE:\n\t\t";
    
    for(Line l : lines)
    {
      for(Word w : l.getWords())
      {
        str += w.getWord() + " ";
      }
      str += "\n\t";
    }
    str += "CALLED AT:\n\t... ";
    
    for(Word w : words)
    {
      str += w.getWord() + " ";
    }
    
    str += " ...\n\n";
    
    return str;
  }
  
}
class Line
{
  
  //Variable declarations
  protected ArrayList<Word> words;
  protected Actor actor;
  protected int actorPos;
  //posOnPage describes the Line's position relative to the beginning of the Page.
  protected PVector posOnPage;
  protected int page;
  
  //Constructors
  //Default Constructor
  Line()
  {
    
    words = new ArrayList<Word>();
    posOnPage = new PVector();
    
  }
  
  //Page number and Actor Constructor
  Line(Actor a, int p)
  {
    
    words = new ArrayList<Word>();
    actor = a;
    posOnPage = new PVector();
    page = p;
    
  }
  
  //Full Constructor
  Line(ArrayList<Word> w, Actor a, int p)
  {
    
    words = w;
    actor = a;
    posOnPage = new PVector();
    page = p;
    
  }
  
  //Full Constructor creates words from String
  Line(String s, Actor a, int p)
  {
    
    words = new ArrayList<Word>();
    
    for(String word : s.split(" "))
    {
      
      words.add(new Word(word));
      
    }
    
    actor = a;
    posOnPage = new PVector();
    page = p;
    
  }
  
  //Constructor for loading in
  Line(Actor a, int p, PVector pos)
  {
    
    words = new ArrayList<Word>();
    actor = a;
    page = p;
    posOnPage = pos;
    
  }
  
  //Get and set page number
  public int getPage()
  {
    
    return page;
    
  }
  
  public void setPage(int p)
  {
    
    page = p;
    
  }
  
  //Get and set words (or Words in words)
  public ArrayList<Word> getWords()
  {
    
    return words;
    
  }
  
  public Word getWord(int i)
  {
    
    return words.get(i);
    
  }
  
  public void setWords(ArrayList<Word> w)
  {
    
    words = w;
    
  }
  
  public void setWord(int i, Word word)
  {
    
    if(i < words.size())
      words.set(i, word);
    
  }
  
  public void setWord(int i, String word)
  {
    
    if(i < words.size())
      words.set(i, new Word(word));
    
  }
  
  //Add to words
  public void addWord(Word word)
  {
    
    words.add(word);
    
  }
  
  public void addWord(String word)
  {
    
    words.add(new Word(word));
    
  }
  
  public void addWord(int i, String word)
  {
    
    words.add(i, new Word(word));
    
  }
  
  public Word removeWord(int i)
  {
    
    return words.remove(i);
    
  }
  
  //Get and set actor
  public Actor getActor()
  {
    
    return actor;
    
  }
  
  public void setActor(Actor a)
  {
    
    actor = a;
    
  }
  
  //Get and set actorPos
  public int getActorPos()
  {
    
    return actorPos;
    
  }
  
  public void setActorPos(int p)
  {
    
    actorPos = p;
    
  }
  
  //Get and set posOnPage
  public PVector getPos()
  {
    
    return posOnPage;
    
  }
  
  public void setPos(float x, float y)
  {
    
    posOnPage.set(x, y);
    
  }
  
  //toString
  public String toString()
  {
    
    String toReturn = "";
    toReturn += actor.charName + ".";
    
    for(Word word : words)
    {
      
      toReturn += word + " ";
      
    }
    
    toReturn += "(" + page + ")";
    
    return toReturn;
    
  }
  
}
class Menu
{
  
  //Variable declarations
  protected PVector topLeftPos;
  protected PVector bottomRightPos;
  protected ArrayList<MenuButton> buttons;
  static final String LONGEST = "CALLED FOR LINE";
  static final int COUNT = 4;
  
  //Constructors
  //Default Constructor
  Menu()
  {
    
    topLeftPos = new PVector();
    bottomRightPos = new PVector();
    buttons = new ArrayList<MenuButton>();
    
  }
  
  //Position constructor
  Menu(PVector tlp, float w)
  {
    
    topLeftPos = tlp;
    buttons = new ArrayList<MenuButton>();
    buttons.add(new MenuButton(tlp.x, tlp.y, tlp.x + 2 * xMargin + w, tlp.y + textHeight, "SKIPPED"));
    buttons.add(new MenuButton(tlp.x, tlp.y + textHeight, tlp.x + 2 * xMargin + w, tlp.y + 2 * textHeight, "PARAPHRASED"));
    buttons.add(new MenuButton(tlp.x, tlp.y + 2 * textHeight, tlp.x + 2 * xMargin + w, tlp.y + 3 * textHeight, "CALLED FOR LINE"));
    buttons.add(new MenuButton(tlp.x, tlp.y + 3 * textHeight, tlp.x + 2 * xMargin + w, tlp.y + 4 * textHeight, "MISSED CUE"));
    
  }
  
  //Get and set buttons
  public ArrayList<MenuButton> getButtons()
  {
    
    return buttons;
    
  }
  
  //Add the rest later
  
}
class MenuButton extends Button
{
  
  //Default Constructor
  MenuButton()
  {
    
    super();
    
  }
  
  //Constructor given text
  MenuButton(String txt)
  {
    
    super(txt);
    
  }
  
  MenuButton(float tlpx, float tlpy, float brpx, float brpy, String txt)
  {
    
    topLeftPos = new PVector(tlpx, tlpy);
    bottomRightPos = new PVector(brpx, brpy);
    text = txt;
    typing = false;
    
  }
  
  //Constructor given 5 inputs
  MenuButton(float px, float py, String txt, boolean t, boolean l)
  {
    
    super(px, py, txt, t, l);
    
  }
  
  //Display Method
  public void display()
  {
    
    rectMode(CORNERS);
    textAlign(CENTER, TOP);
    noStroke();
    
    if((mouseX > topLeftPos.x && mouseX < bottomRightPos.x && mouseY > topLeftPos.y && mouseY < bottomRightPos.y) || typing)
    {
      
      fill(0, 0, 255);
      rect(topLeftPos.x, topLeftPos.y, bottomRightPos.x, bottomRightPos.y);
      fill(0);
      text(text, topLeftPos.x + xMargin + textWidth(Menu.LONGEST) / 2, topLeftPos.y);
      
    }
    
    else
    {
      
      fill(153);
      rect(topLeftPos.x, topLeftPos.y, bottomRightPos.x, bottomRightPos.y);
      fill(255);
      text(text, topLeftPos.x + xMargin + textWidth(Menu.LONGEST) / 2, topLeftPos.y);
      
    }
    
  }
  
}
class MissedCueNote extends Note
{
  
  //Constructors
  //Default Constructor
  MissedCueNote()
  {
    
    super();
    type = 0;
    
  }
  
  //Constructor given lines and words
  MissedCueNote(ArrayList<Line> ls, ArrayList<Word> ws)
  {
    
    super();
    lines.addAll(ls);
    words.addAll(ws);
    type = 3;
    
    for(Line line : lines)
    {
      
      if(actors.indexOf(line.getActor()) == -1)
        actors.add(line.getActor());
        
    }
    
    giveToActors();
    
  }
  
  public String toString()
  {
    String str = "MISSED CUE, PAGE "+str(lines.get(0).getPage())+"\n\tLINE:\n\t\t";
    
    for(Line l : lines)
    {
      for(Word w : l.getWords())
      {
        str += w.getWord() + " ";
      }
      str += "\n\t";
    }
    str += "MISSED:\n\t... ";
    
    for(Word w : words)
    {
      str += w.getWord() + " ";
    }
    
    str += " ...\n\n";
    
    return str;
  }
  
}
class Note
{
  
  protected ArrayList<Line> lines;
  protected ArrayList<Word> words;
  protected ArrayList<Actor> actors;
  protected int type;
  protected int rehearsal;
  
  //Default Constructor
  Note()
  {
    
    rehearsal = currentRehearsal;
    lines = new ArrayList<Line>();
    words = new ArrayList<Word>();
    actors = new ArrayList<Actor>();
    
  }
  
  public void giveToActors()
  {
    
    for(Actor actor : actors)
    {
      
      actor.addNote(this);
      
    }
    
  }
  
  //Get lines
  public ArrayList<Line> getLines()
  {
    
    return lines;
    
  }
  
  public Line getLine(int i)
  {
    
    return lines.get(i);
    
  }
  
  public void addLine(Line line)
  {
    
    lines.add(line);
    
  }
  
  //Get words
  public ArrayList<Word> getWords()
  {
    
    return words;
    
  }
  
  public Word getWord(int i)
  {
    
    return words.get(i);
    
  }
  
  public void addWord(Word word)
  {
    
    words.add(word);
    
  }
  
  //Get and set actors
  public ArrayList<Actor> getActors()
  {
    
    return actors;
    
  }
  
  public void addActor(Actor a)
  {
    
    actors.add(a);
    
  }
  
  //Get type
  public int getType()
  {
    
    return type;
    
  }
  
  //Get and set rehearsal
  public int getRehearsal()
  {
    
    return rehearsal;
    
  }
  
  public void setRehearsal(int r)
  {
    
    rehearsal = r;
    
  }
  
  //Overriden in ParaphraseNote
  public void actorSaid(String s)
  {
  }
  
  public String getSaid()
  {
    
    return "";
    
  }
  
  public String toString()
  {
    return "";
  }
  
}
class Page
{
  
  //Variable declarations
  protected ArrayList<Line> lines;
  protected int number;
  protected PVector pos;
  
  //Constructor
  //Default Constructor
  Page()
  {
    
    lines = new ArrayList<Line>();
    pos = new PVector();
    
  }
  
  //Constructor given page number
  Page(int p)
  {
    
    lines = new ArrayList<Line>();
    number = p;
    pos = new PVector();
    
  }
  
  Page(int p, PVector po)
  {
    
    lines = new ArrayList<Line>();
    number = p;
    pos = po;
    
  }
  
  //Get and set page number
  public int getNumber()
  {
    
    return number;
    
  }
  
  public void setNumber(int p)
  {
    
    number = p;
    
  }
  
  //Get and set lines
  public ArrayList<Line> getLines()
  {
    
    return lines;
    
  }
  
  public Line getLine(int i)
  {
    
    return lines.get(i);
    
  }
  
  public void setLine(int i, Line l)
  {
    
    lines.set(i, l);
    
  }
  
  public void addLine(Line l)
  {
    
    lines.add(l);
    
  }
  
  //Get and set pos
  public PVector getPos()
  {
    
    return pos;
    
  }
  
  public void setPos(PVector p)
  {
    
    pos = p;
    
  }
  
  public void setPos(float x, float y)
  {
    
    pos.set(x, y);
    
  }
  
}
class ParaphraseNote extends Note
{
  
  String said;
  
  ParaphraseNote()
  {
    
    super();
    said = "";
    type = 1;
    
  }
  
  ParaphraseNote(ArrayList<Line> ls, ArrayList<Word> ws)
  {
    
    super();
    lines.addAll(ls);
    words.addAll(ws);
    type = 1;
    
    for(Line line : lines)
    {
      
      if(actors.indexOf(line.getActor()) == -1)
        actors.add(line.getActor());
        
    }
    
    giveToActors();
    
  }
  
  public void actorSaid(String s)
  {
    
    said = s;
    
  }
  
  public String getSaid()
  {
    
    return said;
    
  }
  
  public String toString()
  {
    String str = "CALLED FOR LINE, PAGE "+str(lines.get(0).getPage())+"\n\tLINE:\n\t\t";
    
    for(Line l : lines)
    {
      for(Word w : l.getWords())
      {
        str += w.getWord() + " ";
      }
      str += "\n\t";
    }
    str += "ACTOR SAID:\n\t";
    
    str += said;
    
    str +="\nINSTEAD OF:\n\t\t... ";
    
    for(Word w : words)
    {
      str += w.getWord() + " ";
    }
    
    str += " ...\n\n";
    
    return str;
  }
  
}
class Script 
{
  /*NOTES
   
   Where is space after character period coming from?
   Edit words and paraphrase will only work on the first line selected
   
   */

  /*TODO
   
   Instead of missing page announcement, search for page number first to see if the missing page number can be found
   Fix separateLines() so that each interlinear line poses a question
   Gil still wants to recognize stage directions (idea for that, do this in word before converting to txt).
   Jumped line and missed cue
   
   */

  //Import IO

  //Declare Array to read in each line of the script text file
  String[] script;
  String[] actorArray;
  String[] pageArray;
  String[] lineArray;
  String[] noteArray;

  //Declare ArrayLists for lines, actors, pages, and notes
  ArrayList<Line> lines;
  ArrayList<Actor> actors;
  ArrayList<Page> pages;
  ArrayList<Note> notes;

  /*Types of Notes
   
   0 = SKIPPED LINE
   1 = PARAPHRASED
   2 = CALLED FOR LINE
   3 = MISSED CUE
   
   */


  //State
  /*ENUM substitutes
   
   0 = Displaying Script
   1 = Missing Page
   2 = Unsaved Quit
   3 = Jump to Page
   4 = Highlighting
   5 = Assigning Note
   6 = Editing script
   7 = Highlighting for edit
   8 = Assigning edit
   9 = Assigning Paraphrase
   10 = Jump to Page edit
   11 = Separating line
   
   */
  static final int DISPLAYSCRIPT = 0;
  static final int MISSINGPAGE = 1;
  static final int UNSAVEDQUIT = 2;
  static final int JUMPTOPAGE = 3;
  static final int HIGHLIGHTING = 4;
  static final int ASSIGNINGNOTE = 5;
  static final int EDITINGSCRIPT = 6;
  static final int HIGHLIGHTINGEDIT = 7;
  static final int ASSIGNINGEDIT = 8;
  static final int ASSIGNINGPPHRASE = 9;
  static final int JUMPTOPAGEEDIT = 10;
  static final int SEPARATELINE = 11;

  int state;
  int prevState; //Necessary for quitting without saving and hitting cancel

  //Buttons
  /*ENUM substitutes
   
   0:
   0, 0 = Quit
   0, 1 = Jump to Page
   0, 2 = Save
   0, 3 = Edit Script
   1:
   1, 0 = Quit
   2:
   2, 0 = Save and Quit
   2, 1 = Don't Save and Quit
   2, 2 = Cancel
   3:
   3, 0 = Quit
   3, 1 = Jump to Page
   3, 2 = Save
   3, 3 = Edit Script
   4:
   4, 0 = Quit
   4, 1 = Jump to Page
   4, 2 = Save
   4, 3 = Edit Script
   5:
   5, 0 = Quit
   5, 1 = Jump to Page
   5, 2 = Save
   5, 3 = Edit Script
   5, 4 = Skipped
   5, 5 = Paraphrase
   5, 6 = Called for line
   6:
   6, 0 = Quit
   6, 1 = Jump to Page
   6, 2 = Save
   6, 3 = Back
   6, 4 = Edit words
   6, 5 = Separate line
   6, 6 = Add line
   6, 7 = Remove line
   7:
   7, 0 = Quit
   7, 1 = Jump to Page
   7, 2 = Save
   7, 3 = Back
   
   */
  ArrayList<ArrayList<Button>> buttons;
  boolean editButton;

  //Boolean to chek saved
  boolean saved;

  //Position for display
  PVector startPos;
  PVector pos;

  //Page numbers
  int start;
  int currentPage;

  //Temp string for typing
  String typing;

  //Mouse positions for highlighting
  PVector mouseStart;
  PVector mouseEnd;

  //Selected words
  ArrayList<Word> selected;
  ArrayList<Line> selectedLines;

  //Menu for assigning notes
  Menu menu;

  String prefix;

  Script(String _prefix)
  {
    prefix = _prefix;
    println(prefix);  
    //Set the background color to black
    background(0);
    //Load in the script
    println("Loading Script");
    script = loadStrings(prefix + "/script.txt");
    actorArray = loadStrings(prefix + "/actors.txt");
    pageArray = loadStrings(prefix + "/pages.txt");
    lineArray = loadStrings(prefix + "/lines.txt");
    //noteArray = loadStrings(prefix + "/savedNotes.txt");
    println("Done");
    //Initialize ArrayLists for lines, actors, pages, and notes
    lines = new ArrayList<Line>();
    actors = new ArrayList<Actor>();
    pages = new ArrayList<Page>();
    notes = new ArrayList<Note>();
    //Set state to 0
    state = DISPLAYSCRIPT;
    //Initialize buttons
    buttons = new ArrayList<ArrayList<Button>>();
    editButton = false;
    //Initially saved
    saved = true;
    //Initialize pos
    startPos = new PVector(xMargin, 4 * yMargin + textHeight);
    pos = startPos;
    //Separate the Lines
    println("Separating Lines");
    separateLines();
    println("Done");
    currentPage = start;
    //Create the buttons
    addButtons();
    buttons.get(DISPLAYSCRIPT).get(1).setText("JUMP TO PAGE: " + currentPage);
    println("Setup Done");
  }

  public void draw()
  {

    background(0);

    switch(state)
    {
    case DISPLAYSCRIPT:
    case JUMPTOPAGE:
    case HIGHLIGHTING:
    case ASSIGNINGNOTE:
    case EDITINGSCRIPT:
    case HIGHLIGHTINGEDIT:
    case JUMPTOPAGEEDIT:
    case SEPARATELINE:

      displayScript();
      break;

    case MISSINGPAGE:

      fill(255);
      textAlign(CENTER, CENTER);
      text("MISSING PAGE " + lines.get(lines.size() - 1).getPage() + ", PLEASE CORRECT SCRIPT", width / 2, height / 2);
      break;

    case UNSAVEDQUIT:

      fill(255);
      textAlign(CENTER, CENTER);
      text("NOT SAVED, WOULD YOU LIKE TO SAVE CHANGES?", width / 2, height / 2);
      break;

    case ASSIGNINGEDIT:

      displayScript();
      fill(255, 0, 0);
      text("CHANGE TO: " + typing, xMargin, pages.get(selectedLines.get(0).getPage() - start).getPos().y + selectedLines.get(0).getPos().y - textHeight - pos.y);
      break;

    case ASSIGNINGPPHRASE:

      displayScript();
      fill(255, 0, 0);
      text("ACTOR SAID: " + typing, xMargin, pages.get(selectedLines.get(0).getPage() - start).getPos().y + selectedLines.get(0).getPos().y - textHeight - pos.y);
      break;
    }

    //Display all the buttons for this state
    for (Button button : buttons.get (state))
    {

      button.display();
    }
  }

  public void mousePressed()
  {

    //Boolean for whether or not a button has been clicked
    boolean buttonClicked = false;

    //Run through the buttons in this state
    for (int i = 0; i < buttons.get (state).size(); i++)
    {
      //Check to see if the button has been pressed
      if (mouseX >= buttons.get(state).get(i).getTLPx() && mouseX <= buttons.get(state).get(i).getBRPx() && mouseY >= buttons.get(state).get(i).getTLPy() && mouseY <= buttons.get(state).get(i).getBRPy())
      {
        buttonClicked = true;
        buttonClick(state, i);
        break;
      }
    }

    //Only enter here if no button has been pressed
    if (!buttonClicked)
    {

      switch(state)
      {

      case DISPLAYSCRIPT:

        mouseStart = new PVector(mouseX, mouseY);
        selected = new ArrayList<Word>();
        selectedLines = new ArrayList<Line>();

        for (Page page : pages)
        {

          if (page.getPos().y > height + pos.y)
            break;

          if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
          {

            for (Line line : page.getLines ())
            {

              boolean lineSelected = false;

              for (Word word : line.getWords ())
              {

                if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseStart.x >= page.getPos().x + line.getPos().x + word.getPos().x))
                {

                  lineSelected = true;
                  word.setHighlight(true);
                  selected.add(word);
                } else
                {

                  word.setHighlight(false);
                }
              }

              if (lineSelected)
                selectedLines.add(line);
            }
          }
        }

        state = HIGHLIGHTING;
        break;

      case 3:

        buttons.get(JUMPTOPAGE).get(1).setTyping(false);
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + currentPage);
        state = DISPLAYSCRIPT;
        break;

      case 5:

        for (Word word : selected)
        {

          word.setHighlight(false);
        }

        mouseStart = new PVector(mouseX, mouseY);
        selected.clear();
        selectedLines.clear();

        for (Page page : pages)
        {

          if (page.getPos().y > height + pos.y)
            break;

          if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
          {

            for (Line line : page.getLines ())
            {

              boolean lineSelected = false;

              for (Word word : line.getWords ())
              {

                if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseStart.x >= page.getPos().x + line.getPos().x + word.getPos().x))
                {

                  lineSelected = true;
                  word.setHighlight(true);
                  selected.add(word);
                } else
                {

                  word.setHighlight(false);
                }
              }

              if (lineSelected)
                selectedLines.add(line);
            }
          }
        }

        buttons.get(ASSIGNINGNOTE).clear();
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
        state = HIGHLIGHTING;
        break;

      case HIGHLIGHTINGEDIT:

        mouseStart = new PVector(mouseX, mouseY);
        selected = new ArrayList<Word>();
        selectedLines = new ArrayList<Line>();

        for (Page page : pages)
        {

          if (page.getPos().y > height + pos.y)
            break;

          if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
          {

            for (Line line : page.getLines ())
            {

              boolean lineSelected = false;

              for (Word word : line.getWords ())
              {

                if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseStart.x >= page.getPos().x + line.getPos().x + word.getPos().x))
                {

                  lineSelected = true;
                  word.setHighlight(true);
                  selected.add(word);
                } else
                {

                  word.setHighlight(false);
                }
              }

              if (lineSelected)
                selectedLines.add(line);
            }
          }
        }

        break;
      }
    }
  }

  public void mouseDragged()
  {

    if (state == HIGHLIGHTING)
    {

      PVector mouseEnd = new PVector(mouseX, mouseY);
      selected = new ArrayList<Word>();
      selectedLines = new ArrayList<Line>();

      for (Page page : pages)
      {

        if (page.getPos().y > height + pos.y)
          break;

        if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
        {

          for (Line line : page.getLines ())
          {

            boolean lineSelected = false;

            for (Word word : line.getWords ())
            {

              if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x))
              {

                lineSelected = true;
                word.setHighlight(true);
                selected.add(word);
              } else
              {

                word.setHighlight(false);
              }
            }

            if (lineSelected)
              selectedLines.add(line);
          }
        }
      }

      if (selected.size() == 0)
      {

        PVector temp = mouseStart;
        mouseStart = mouseEnd;
        mouseEnd = temp;

        for (Page page : pages)
        {

          if (page.getPos().y > height + pos.y)
            break;

          if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
          {

            for (Line line : page.getLines ())
            {

              boolean lineSelected = false;

              for (Word word : line.getWords ())
              {

                if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x))
                {

                  lineSelected = true;
                  word.setHighlight(true);
                  selected.add(word);
                } else
                {

                  word.setHighlight(false);
                }
              }

              if (lineSelected)
                selectedLines.add(line);
            }
          }
        }

        mouseEnd = mouseStart;
        mouseStart = temp;
      }
    } else if (state == HIGHLIGHTINGEDIT)
    {

      PVector mouseEnd = new PVector(mouseX, mouseY);
      selected = new ArrayList<Word>();
      selectedLines = new ArrayList<Line>();

      for (Page page : pages)
      {

        if (page.getPos().y > height + pos.y)
          break;

        if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
        {

          for (Line line : page.getLines ())
          {

            boolean lineSelected = false;

            for (Word word : line.getWords ())
            {

              if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x))
              {

                lineSelected = true;
                word.setHighlight(true);
                selected.add(word);
              } else
              {

                word.setHighlight(false);
              }
            }

            if (lineSelected)
              selectedLines.add(line);
          }
        }
      }

      if (selected.size() == 0)
      {

        PVector temp = mouseStart;
        mouseStart = mouseEnd;
        mouseEnd = temp;

        for (Page page : pages)
        {

          if (page.getPos().y > height + pos.y)
            break;

          if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
          {

            for (Line line : page.getLines ())
            {

              boolean lineSelected = false;

              for (Word word : line.getWords ())
              {

                if ((mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord())) || (mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x) || (mouseStart.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y <= page.getPos().y + line.getPos().y + word.getPos().y - pos.y + textHeight && mouseEnd.y >= page.getPos().y + line.getPos().y + word.getPos().y - pos.y && mouseStart.x <= page.getPos().x + line.getPos().x + word.getPos().x + textWidth(word.getWord()) && mouseEnd.x >= page.getPos().x + line.getPos().x + word.getPos().x))
                {

                  lineSelected = true;
                  word.setHighlight(true);
                  selected.add(word);
                } else
                {

                  word.setHighlight(false);
                }
              }

              if (lineSelected)
                selectedLines.add(line);
            }
          }
        }

        mouseEnd = mouseStart;
        mouseStart = temp;
      }
    }
  }

  public void mouseReleased()
  {

    if (state == HIGHLIGHTING)
    {

      if (selected.size() > 0)
      {

        state = ASSIGNINGNOTE;
        prepareMenu(mouseX, mouseY);
      } else
      {

        state = DISPLAYSCRIPT;
      }
    } else if (state == EDITINGSCRIPT)
    {

      if (editButton)
      {

        state = HIGHLIGHTINGEDIT;
        editButton = false;
      }
    } else if (state == HIGHLIGHTINGEDIT)
    {

      if (selected.size() > 0)
      {

        state = ASSIGNINGEDIT;
        typing = "";
      } else
      {

        state = EDITINGSCRIPT;
      }
    }
  }

  public void keyPressed()
  {

    switch(state)
    {

    case DISPLAYSCRIPT:
    case EDITINGSCRIPT:

      //Scroll down in script
      if (keyCode == DOWN)
      {

        if (pos.y < pages.get(pages.size() - 1).getPos().y + pages.get(pages.size() - 1).getLine(pages.get(pages.size() - 1).getLines().size() - 1).getPos().y + pages.get(pages.size() - 1).getLine(pages.get(pages.size() - 1).getLines().size() - 1).getWord(pages.get(pages.size() - 1).getLine(pages.get(pages.size() - 1).getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight - height / 2)
        {

          pos.y += textHeight;
        }

        //If at the bottom, change currentPage to the last page (may not go down far enough to do so automatically)
        else
        {

          buttons.get(DISPLAYSCRIPT).get(1).setText("JUMP TO PAGE: " + pages.get(pages.size() - 1).getNumber());
        }

        //If passing to the next page, changes currentPage
        if (currentPage - start < pages.size() - 1 && pages.get(currentPage - start + 1).getPos().y <= 4 * yMargin + textHeight + pos.y)
        {

          currentPage++;
          buttons.get(DISPLAYSCRIPT).get(1).setText("JUMP TO PAGE: " + currentPage);
        }
      }

      //Scroll up in script
      else if (keyCode == UP)
      {

        if (pos.y > 4 * yMargin + textHeight)
        {

          pos.y -= textHeight;
        }

        //If passing to the previous page, changes currentPage
        if (currentPage - start > 0 && pages.get(currentPage - start).getPos().y >= 4 * yMargin + textHeight + pos.y)
        {

          currentPage--;
          buttons.get(DISPLAYSCRIPT).get(1).setText("JUMP TO PAGE: " + currentPage);
        }
      } else if (keyCode == RIGHT)
      {

        if (currentPage - start < pages.size() - 1)
        {

          currentPage++;
          buttons.get(DISPLAYSCRIPT).get(1).setText("JUMP TO PAGE: " + currentPage);
          pos.set(pages.get(currentPage - start).getPos().x, pages.get(currentPage - start).getPos().y - 4 * yMargin - textHeight);
        }
      } else if (keyCode == LEFT)
      {

        if (currentPage - start > 0)
        {

          if (pos.y + 4 * yMargin + textHeight == pages.get(currentPage - start).getPos().y)
          {

            currentPage--;
            buttons.get(DISPLAYSCRIPT).get(1).setText("JUMP TO PAGE: " + currentPage);
            pos.set(pages.get(currentPage - start).getPos().x, pages.get(currentPage - start).getPos().y - 4 * yMargin - textHeight);
          } else
          {

            pos.set(pages.get(currentPage - start).getPos().x, pages.get(currentPage - start).getPos().y - 4 * yMargin - textHeight);
          }
        } else
        {

          pos.set(pages.get(currentPage - start).getPos().x, pages.get(currentPage - start).getPos().y - 4 * yMargin - textHeight);
        }
      }

      break;

    case JUMPTOPAGE:

      if (key >= 48 && key <= 57)
      {

        typing += key;
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + typing);
      } else if (key == 8 && typing.length() > 0)
      {

        typing = typing.substring(0, typing.length() - 1);
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + typing);
      } else if (keyCode == ENTER || keyCode == RETURN)
      {

        if (pageNumber(typing) >= start && pageNumber(typing) <= pages.get(pages.size() - 1).getNumber())
        {

          currentPage = pageNumber(typing);
          buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + currentPage);
          buttons.get(JUMPTOPAGE).get(1).setTyping(false);
          pos.set(pages.get(currentPage - start).getPos().x, pages.get(currentPage - start).getPos().y - 4 * yMargin - textHeight);
          typing = "";
          state = DISPLAYSCRIPT;
        } else
        {

          key = 27;
        }
      }

      if (key == 27)
      {

        key = 0;
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + currentPage);
        buttons.get(JUMPTOPAGE).get(1).setTyping(false);
        typing = "";
        state = DISPLAYSCRIPT;
      }

      break;

    case JUMPTOPAGEEDIT:

      if (key >= 48 && key <= 57)
      {

        typing += key;
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + typing);
      } else if (key == 8 && typing.length() > 0)
      {

        typing = typing.substring(0, typing.length() - 1);
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + typing);
      } else if (keyCode == ENTER || keyCode == RETURN)
      {

        if (pageNumber(typing) >= start && pageNumber(typing) <= pages.get(pages.size() - 1).getNumber())
        {

          currentPage = pageNumber(typing);
          buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + currentPage);
          buttons.get(JUMPTOPAGE).get(1).setTyping(false);
          pos.set(pages.get(currentPage - start).getPos().x, pages.get(currentPage - start).getPos().y - 4 * yMargin - textHeight);
          typing = "";
          state = EDITINGSCRIPT;
        } else
        {

          key = 27;
        }
      }

      if (key == 27)
      {

        key = 0;
        buttons.get(JUMPTOPAGE).get(1).setText("JUMP TO PAGE: " + currentPage);
        buttons.get(JUMPTOPAGE).get(1).setTyping(false);
        typing = "";
        state = EDITINGSCRIPT;
      }

      break;

    case ASSIGNINGNOTE:

      if (key == 27)
      {

        key = 0;

        for (Word word : selected)
        {

          word.setHighlight(false);
        }

        mouseStart = null;
        selected.clear();
        selectedLines.clear();
        buttons.get(ASSIGNINGNOTE).clear();
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
        state = DISPLAYSCRIPT;
      }

      break;

    case ASSIGNINGEDIT:

      if ((keyCode >= 48 && keyCode <= 90) || key == ',' || key == '.' || key == ':' || key == ';' || key == '-' || key == '\'' || key == '!' || key == '?' || key == ' '  || key == '(' || key == ')')
      {

        typing += key;
      } else if (key == 8 && typing.length() > 0)
      {

        typing = typing.substring(0, typing.length() - 1);
      } else if (keyCode == ENTER || keyCode == RETURN)
      {

        int temp = selectedLines.get(0).getWords().indexOf(selected.get(0));
        saved = false;

        for (String word : typing.split (" "))
        {

          selectedLines.get(0).addWord(temp, word);
          temp++;
        }

        for (int i = selected.size () - 1; i >= 0; i--)
        {

          if (selectedLines.get(0).getWords().indexOf(selected.get(i)) != -1)
          {

            selectedLines.get(0).removeWord(selectedLines.get(0).getWords().indexOf(selected.get(i)));
          } else
          {

            selected.get(i).setHighlight(false);
            selected.remove(i);
          }
        }

        assignPositionsOld();
        selected.clear();
        selectedLines.clear();
        typing = "";
        state = EDITINGSCRIPT;
      } else if (key == 27)
      {

        key = 0;

        for (Word word : selected)
        {

          word.setHighlight(false);
        }

        selected.clear();
        selectedLines.clear();
        typing = "";
        state = EDITINGSCRIPT;
      }

      break;

    case ASSIGNINGPPHRASE:

      if ((keyCode >= 48 && keyCode <= 90) || key == ',' || key == '.' || key == ':' || key == ';' || key == '-' || key == '\'' || key == '!' || key == '?' || key == ' '  || key == '(' || key == ')')
      {

        typing += key;
      } else if (key == 8 && typing.length() > 0)
      {

        typing = typing.substring(0, typing.length() - 1);
      } else if (keyCode == ENTER || keyCode == RETURN)
      {

        saved = false;
        notes.get(notes.size() - 1).actorSaid(typing);

        for (Word word : selected)
        {

          word.setHighlight(false);
        }

        selected.clear();
        selectedLines.clear();
        typing = "";
        state = DISPLAYSCRIPT;
      } else if (key == 27)
      {

        key = 0;

        for (Word word : selected)
        {

          word.setHighlight(false);
        }

        selected.clear();
        selectedLines.clear();
        typing = "";
        state = EDITINGSCRIPT;
      }

      break;
    }
  }

  public void displayScript()
  {

    textAlign(LEFT, TOP);

    //Loop through the pages
    for (Page page : pages)
    {

      //If the page is past the bottom of the display, quit the loop
      if (page.getPos().y > height + pos.y)
        break;

      //If the page should be displayed, enter this if
      if (page.getPos().y + page.getLine(page.getLines().size() - 1).getPos().y + page.getLine(page.getLines().size() - 1).getWord(page.getLine(page.getLines().size() - 1).getWords().size() - 1).getPos().y + textHeight >= pos.y)
      {

        //Display the page number
        fill(255);
        textAlign(CENTER, TOP);
        text("PAGE " + page.getNumber(), width / 2, page.getPos().y - pos.y);
        //Prepare to display the lines that are on the page
        textAlign(LEFT, TOP);

        //Loop through the lines on the page
        for (Line line : page.getLines ())
        {

          //If the line is past the bottom of the display, quit the loop
          if (page.getPos().y + line.getPos().y > height + pos.y)
            break;

          fill(255);
          //Display the actor
          text(line.getActor().getCharName() + ".", page.getPos().x + line.getPos().x, page.getPos().y + line.getPos().y - pos.y);


          for (Word word : line.getWords ())
          {

            //If the word is past the bottom of the display, quit the loop
            if (page.getPos().y + line.getPos().y + word.getPos().y > height + pos.y)
              break;

            fill(255);

            if (word.isHighlighted())
            {

              switch(state)
              {

              case HIGHLIGHTING:
              case HIGHLIGHTINGEDIT:

                fill(0, 255, 255);
                break;

              case ASSIGNINGNOTE:
              case ASSIGNINGEDIT:

                fill(0, 255, 0);
                break;
              }
            }

            //Display the word
            text(word.getWord() + " ", page.getPos().x + line.getPos().x + word.getPos().x, page.getPos().y + line.getPos().y + word.getPos().y - pos.y);
          }
        }
      }
    }
  }

  public void separateLines()
  {

    if (actorArray == null || pageArray == null || lineArray == null || actorArray.length == 0 || pageArray.length == 0 || lineArray.length == 0)
    {

      //Temporary integer to store page number
      int page = -1;

      //Loops through every line of the script's text file
      for (String s : script)
      {

        //Checks if the line contains only a number
        if (pageNumber(s) != -1)
        {

          //Checks to make sure the new page number is one more than the previous page number (or the first page number reached)
          if (page != -1 && page != pageNumber(s))
          {

            state = MISSINGPAGE;
            break;
          } else
          {

            //Checks if this is the first page number, in which case it reassigns all previous pages to have this page number
            if (page == -1)
            {

              start = pageNumber(s);

              for (Line line : lines)
              {

                line.setPage(start);
              }
            }

            page = pageNumber(s) + 1;
          }
        }

        //This runs if the line is not a number
        else
        {

          //First check if the line has no actors in it
          if (s.indexOf('.') == -1 || !s.substring(0, s.indexOf('.')).toUpperCase().equals(s.substring(0, s.indexOf('.'))))
          {

            for (String word : s.split (" "))
            {

              if (lines.size() > 0)
                lines.get(lines.size() - 1).addWord(word);
            }
          } else
          {

            //Boolean for whether or not the actor currently exists
            boolean actorExists = false;

            //Loop through all the actors
            for (Actor actor : actors)
            {

              //If the Line's Actor exists, add a new Line with the current page number, the Line's Actor, and the words
              if (actor.charName.equals(s.substring(0, s.indexOf('.'))))
              {

                //Add the blank Line with Actor actor and page number page
                lines.add(new Line(s.substring(s.indexOf('.') + 1), actor, page));

                //Break out of the Actor loop and set actorExists to be true
                actorExists = true;
                break;
              }
            }

            //This runs if the Actor does not exist
            if (!actorExists)
            {

              //Adds the Actor to actors and adds the new Line
              actors.add(new Actor(s.substring(0, s.indexOf('.'))));
              lines.add(new Line(s.substring(s.indexOf('.') + 1), actors.get(actors.size() - 1), page));
            }
          }
        }
      }

      /* Not needed
       //Loops through every line to find lines with another line hidden in them
       for (int i = 0; i < lines.size (); i++)
       {
       
       //Loops through every actor to check if the line has their name capitalized
       for (Actor actor : actors)
       {
       
       //Loops through every word in lines.get(i) to compare with actor's name
       for (int j = 0; j < lines.get (i).getWords().size(); j++)
       {
       
       //Checks if the word is the actor's name capitalized with or without a period
       if (lines.get(i).getWord(j).getWord().equals(actor.getCharName()) || lines.get(i).getWord(j).getWord().equals(actor.getCharName() + "."))
       {
       
       //Separates the line into two separate lines
       lines.get(i).setWord(j + 1, " " + lines.get(i).getWord(j + 1).getWord());
       lines.add(i + 1, new Line(new ArrayList<Word>(lines.get(i).getWords().subList(j + 1, lines.get(i).getWords().size())), actor, lines.get(i).getPage()));
       lines.get(i).setWords(new ArrayList<Word>(lines.get(i).getWords().subList(0, j)));
       }
       }
       }
       }//*/

      assignPositionsNew();
    } else
    {

      for (int i = 0; i < actorArray.length; i += 2)
      {

        actors.add(new Actor(actorArray[i], actorArray[i + 1]));
      }

      for (int i = 0; i < pageArray.length; i += 2)
      {

        pages.add(new Page(Integer.parseInt(pageArray[i]), vectorFromString(pageArray[i + 1])));
      }

      start = pages.get(0).getNumber();

      int counter = 0;

      while (counter < lineArray.length)
      {

        Actor actor = actors.get(Integer.parseInt(lineArray[counter]));
        Page page = pages.get(Integer.parseInt(lineArray[counter + 1]) - start);
        PVector p = vectorFromString(lineArray[counter + 2]);
        lines.add(new Line(actor, page.getNumber(), p));
        counter += 3;

        for (int i = counter + 1; i < counter + 1 + 2 * Integer.parseInt (lineArray[counter]); i += 2)
        {
          lines.get(lines.size() - 1).addWord(new Word(lineArray[i], vectorFromString(lineArray[i + 1])));
        }

        counter += 1 + 2 * Integer.parseInt(lineArray[counter]);
        page.addLine(lines.get(lines.size() - 1));
      }
    }

    if (noteArray == null || noteArray.length == 0)
    {

      currentRehearsal = 1;
    } else
    {

      int counter = 0;

      while (counter < noteArray.length)
      {
        println(counter);
        switch(Integer.parseInt(noteArray[counter]))
        {

        case 0:

          notes.add(new SkipNote());
          counter++;

          for (int i = counter + 1; i < counter + 1 + Integer.parseInt (noteArray[counter]); i++)
          {

            notes.get(notes.size() - 1).addActor(actors.get(Integer.parseInt(noteArray[i])));
          }

          notes.get(notes.size() - 1).giveToActors();
          counter += 1 + Integer.parseInt(noteArray[counter]);
          int temp0 = Integer.parseInt(noteArray[counter]);
          counter++;

          for (int i = 0; i < temp0; i++)
          {

            notes.get(notes.size() - 1).addLine(lines.get(Integer.parseInt(noteArray[counter])));
            counter++;

            for (int j = counter + 1; j < counter + 1 + Integer.parseInt (noteArray[counter]); j++)
            {

              notes.get(notes.size() - 1).addWord(notes.get(notes.size() - 1).getLine(notes.get(notes.size() - 1).getLines().size() - 1).getWord(Integer.parseInt(noteArray[j])));
            }

            counter += 1 + Integer.parseInt(noteArray[counter]);
          }

          notes.get(notes.size() - 1).setRehearsal(Integer.parseInt(noteArray[counter]));
          counter++;
          break;

        case 1:

          notes.add(new ParaphraseNote());
          counter++;

          for (int i = counter + 1; i < counter + 1 + Integer.parseInt (noteArray[counter]); i++)
          {

            notes.get(notes.size() - 1).addActor(actors.get(Integer.parseInt(noteArray[i])));
          }

          notes.get(notes.size() - 1).giveToActors();
          counter += 1 + Integer.parseInt(noteArray[counter]);
          int temp1 = Integer.parseInt(noteArray[counter]);
          counter++;

          for (int i = 0; i < temp1; i++)
          {

            notes.get(notes.size() - 1).addLine(lines.get(Integer.parseInt(noteArray[counter])));
            counter++;

            for (int j = counter + 1; j < counter + 1 + Integer.parseInt (noteArray[counter]); j++)
            {

              notes.get(notes.size() - 1).addWord(notes.get(notes.size() - 1).getLine(notes.get(notes.size() - 1).getLines().size() - 1).getWord(Integer.parseInt(noteArray[j])));
            }

            counter += 1 + Integer.parseInt(noteArray[counter]);
          }

          notes.get(notes.size() - 1).actorSaid(noteArray[counter]);
          notes.get(notes.size() - 1).setRehearsal(Integer.parseInt(noteArray[counter + 1]));
          counter += 2;
          break;

        case 2:

          notes.add(new CallForLineNote());
          counter++;

          for (int i = counter + 1; i < counter + 1 + Integer.parseInt (noteArray[counter]); i++)
          {

            notes.get(notes.size() - 1).addActor(actors.get(Integer.parseInt(noteArray[i])));
          }

          notes.get(notes.size() - 1).giveToActors();
          counter += 1 + Integer.parseInt(noteArray[counter]);
          int temp2 = Integer.parseInt(noteArray[counter]);
          counter++;

          for (int i = 0; i < temp2; i++)
          {

            notes.get(notes.size() - 1).addLine(lines.get(Integer.parseInt(noteArray[counter])));
            counter++;

            for (int j = counter + 1; j < counter + 1 + Integer.parseInt (noteArray[counter]); j++)
            {

              notes.get(notes.size() - 1).addWord(notes.get(notes.size() - 1).getLine(notes.get(notes.size() - 1).getLines().size() - 1).getWord(Integer.parseInt(noteArray[j])));
            }

            counter += 1 + Integer.parseInt(noteArray[counter]);
          }

          notes.get(notes.size() - 1).setRehearsal(Integer.parseInt(noteArray[counter]));
          counter++;
          break;
        }
      }

      currentRehearsal = Integer.parseInt(noteArray[counter - 1]) + 1;
    }
  }

  public void assignPositionsNew()
  {

    //Assign positions to each page, line, and word
    //Begin with temporary variable declarations for page and line
    float tempPagePos = startPos.y;
    float tempLinePos = 2 * textHeight + yMargin;

    //Loop through the lines
    for (Line line : lines)
    {

      //Check if this line is on a new page
      if (pages.size() <= line.getPage() - start)
      {

        //If so, adjust the page and line position temporary variables accordingly
        tempPagePos += tempLinePos + 2 * textHeight + yMargin;
        tempLinePos = 2 * textHeight + yMargin;
        //Add a new page with its proper position
        pages.add(new Page(line.getPage(), new PVector(xMargin, tempPagePos)));
      }

      //Add this line to the last page and give the line its position
      pages.get(pages.size() - 1).addLine(line);
      line.setPos(0, tempLinePos);
      //Declare a temporary variable for word position
      PVector tempWordPos = new PVector(textWidth(line.getActor().getCharName() + ". "), 0);

      //Loop through the words assigning positions
      for (Word word : line.getWords ())
      {

        //Check if the word is on the next line, if so adjust word and line positions accordingly
        if (pages.get(pages.size() - 1).getPos().x + line.getPos().x + tempWordPos.x + textWidth(word.getWord()) > width - xMargin)
        {

          tempWordPos.set(0, tempWordPos.y + 2 * textHeight);
          tempLinePos += 2 * textHeight;
        }

        //Iterate through
        word.setPos(tempWordPos.x, tempWordPos.y);
        tempWordPos.x += textWidth(word.getWord() + " ");
      }

      //Iterate through
      tempLinePos += 2 * textHeight;
    }
  }

  public void assignPositionsOld()
  {

    float diffOld = selected.get(selected.size() - 1).getPos().y - selected.get(0).getPos().y;
    float diffNew = 0;
    PVector tempWordPos = new PVector(textWidth(selectedLines.get(0).getActor().getCharName() + ". "), 0);

    for (Word word : selectedLines.get (0).getWords())
    {

      if (pages.get(selectedLines.get(0).getPage() - start).getPos().x + selectedLines.get(0).getPos().x + tempWordPos.x + textWidth(word.getWord()) > width - xMargin)
      {

        tempWordPos.set(0, tempWordPos.y + 2 * textHeight);
        diffNew += 2 * textHeight;
      }

      word.setPos(tempWordPos.x, tempWordPos.y);
      tempWordPos.x += textWidth(word.getWord() + " ");
    }

    if (diffOld != diffNew)
    {

      for (int i = pages.get (selectedLines.get (0).getPage() - start).getLines().indexOf(selectedLines.get(0)) + 1; i < pages.get(selectedLines.get(0).getPage() - start).getLines().size(); i++)
      {

        pages.get(selectedLines.get(0).getPage() - start).getLine(i).setPos(pages.get(selectedLines.get(0).getPage() - start).getLine(i).getPos().x, pages.get(selectedLines.get(0).getPage() - start).getLine(i).getPos().y + diffNew - diffOld);
      }

      for (int i = selectedLines.get (0).getPage() - start + 1; i < pages.size(); i++)
      {

        pages.get(i).setPos(pages.get(i).getPos().x, pages.get(i).getPos().y + diffNew - diffOld);
      }
    }
  }

  //Check to see if s is an integer, returns s or -1
  public int pageNumber(String s)
  {

    try
    {

      return Integer.parseInt(s.split(" ")[0]);
    }

    catch(Exception e)
    {

      return -1;
    }
  }

  public void addButtons()
  {

    //State DISPLAYSCRIPT
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(DISPLAYSCRIPT).add(new Button(width - xMargin, yMargin, "QUIT", true, false));
    //Jump to Page button
    buttons.get(DISPLAYSCRIPT).add(new Button(width - 4 * xMargin - textWidth("QUIT"), yMargin, "JUMP TO PAGE: " + pages.get(pages.size() - 1).getNumber() * 10, true, false));
    //Save button
    buttons.get(DISPLAYSCRIPT).add(new Button(xMargin, yMargin, "SAVE", true, true));
    //Edit script button
    buttons.get(DISPLAYSCRIPT).add(new Button(4 * xMargin + textWidth("SAVE"), yMargin, "EDIT SCRIPT", true, true));
    //State MISSINGPAGE
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(MISSINGPAGE).add(buttons.get(DISPLAYSCRIPT).get(0));
    //State UNSAVEDQUIT
    buttons.add(new ArrayList<Button>());
    //Save button
    buttons.get(UNSAVEDQUIT).add(new Button(width / 2 - 2 * xMargin, height / 2 + textHeight + yMargin, "YES", true, false));
    //Don't save button
    buttons.get(UNSAVEDQUIT).add(new Button(width / 2 + 2 * xMargin, height / 2 + textHeight + yMargin, "NO", true, true));
    //Cancel button
    buttons.get(UNSAVEDQUIT).add(new Button((width - textWidth("CANCEL")) / 2, height / 2 + 2 * textHeight + 4 * yMargin, "CANCEL", true, true));
    //State JUMPTOPAGE
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(JUMPTOPAGE).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(JUMPTOPAGE).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(JUMPTOPAGE).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Edit script button
    buttons.get(JUMPTOPAGE).add(buttons.get(DISPLAYSCRIPT).get(3));
    //State HIGHLIGHTING
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(HIGHLIGHTING).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(HIGHLIGHTING).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(HIGHLIGHTING).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Edit script button
    buttons.get(HIGHLIGHTING).add(buttons.get(DISPLAYSCRIPT).get(3));
    //State ASSIGNINGNOTE
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Edit script button
    buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
    //State EDITINGSCRIPT
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(EDITINGSCRIPT).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(EDITINGSCRIPT).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(EDITINGSCRIPT).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Back button
    buttons.get(EDITINGSCRIPT).add(new Button(4 * xMargin + textWidth("SAVE"), yMargin, "BACK", true, true));
    //Edit words button
    buttons.get(EDITINGSCRIPT).add(new Button(7 * xMargin + textWidth("SAVEBACK"), yMargin, "EDIT WORD(S)", true, true));
    //Separate line button
    //buttons.get(EDITINGSCRIPT).add(new Button(10 * xMargin + textWidth("SAVEBACKEDIT WORD(S)"), yMargin, "SEPARATE LINE", true, true));
    //Add line button
    //buttons.get(EDITINGSCRIPT).add(new Button(xMargin, 4 * yMargin + textHeight, "ADD LINE", true, true));
    //Remove line button
    //buttons.get(EDITINGSCRIPT).add(new Button(4 * xMargin + textWidth("ADD LINE"), 4 * yMargin + textHeight, "REMOVE LINE", true, true));
    //State HIGHLIGHTINGEDIT
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Back button
    buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(EDITINGSCRIPT).get(3));
    //Edit words button
    buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(EDITINGSCRIPT).get(4));
    //Separate line button
    //buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(EDITINGSCRIPT).get(5));
    //Add line button
    //buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(EDITINGSCRIPT).get(6));
    //Remove line button
    //buttons.get(HIGHLIGHTINGEDIT).add(buttons.get(EDITINGSCRIPT).get(7));
    //State ASSIGNINGEDIT
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(ASSIGNINGEDIT).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(ASSIGNINGEDIT).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(ASSIGNINGEDIT).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Back button
    buttons.get(ASSIGNINGEDIT).add(buttons.get(EDITINGSCRIPT).get(3));
    //Edit words button
    buttons.get(ASSIGNINGEDIT).add(buttons.get(EDITINGSCRIPT).get(4));
    //Separate line button
    //buttons.get(ASSIGNINGEDIT).add(buttons.get(EDITINGSCRIPT).get(5));
    //Add line button
    //buttons.get(ASSIGNINGEDIT).add(buttons.get(EDITINGSCRIPT).get(6));
    //Remove line button
    //buttons.get(ASSIGNINGEDIT).add(buttons.get(EDITINGSCRIPT).get(7));
    //State ASSIGNINGPPHRASE
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(ASSIGNINGPPHRASE).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(ASSIGNINGPPHRASE).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(ASSIGNINGPPHRASE).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Edit script button
    buttons.get(ASSIGNINGPPHRASE).add(buttons.get(DISPLAYSCRIPT).get(3));
    //State JUMPTOPAGEEDIT
    buttons.add(new ArrayList<Button>());
    //Quit button
    buttons.get(JUMPTOPAGEEDIT).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    buttons.get(JUMPTOPAGEEDIT).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    buttons.get(JUMPTOPAGEEDIT).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Back button
    buttons.get(JUMPTOPAGEEDIT).add(buttons.get(EDITINGSCRIPT).get(3));
    //Edit words button
    buttons.get(JUMPTOPAGEEDIT).add(buttons.get(EDITINGSCRIPT).get(4));
    //Separate line button
    //buttons.get(JUMPTOPAGEEDIT).add(buttons.get(EDITINGSCRIPT).get(5));
    //Add line button
    //buttons.get(JUMPTOPAGEEDIT).add(buttons.get(EDITINGSCRIPT).get(6));
    //Remove line button
    //buttons.get(JUMPTOPAGEEDIT).add(buttons.get(EDITINGSCRIPT).get(7));
    //State SEPARATELINE
    //buttons.add(new ArrayList<Button>());
    //Quit button
    //buttons.get(SEPARATELINE).add(buttons.get(DISPLAYSCRIPT).get(0));
    //Jump to Page button
    //buttons.get(SEPARATELINE).add(buttons.get(DISPLAYSCRIPT).get(1));
    //Save button
    //buttons.get(SEPARATELINE).add(buttons.get(DISPLAYSCRIPT).get(2));
    //Back button
    //buttons.get(SEPARATELINE).add(buttons.get(EDITINGSCRIPT).get(3));
    //Edit words button
    //buttons.get(SEPARATELINE).add(buttons.get(EDITINGSCRIPT).get(4));
    //Separate line button
    //buttons.get(SEPARATELINE).add(buttons.get(EDITINGSCRIPT).get(5));
    //Add line button
    //buttons.get(SEPARATELINE).add(buttons.get(EDITINGSCRIPT).get(6));
    //Remove line button
    //buttons.get(SEPARATELINE).add(buttons.get(EDITINGSCRIPT).get(7));
  }

  public void buttonClick(int s, int i)
  {

    //
    switch(s)
    {

    case DISPLAYSCRIPT:
    case HIGHLIGHTING:
    case ASSIGNINGNOTE:
    case ASSIGNINGPPHRASE:

      switch(i)
      {

      case 0:

        if (saved)
        {
          exit();
        } else
        {
          state = UNSAVEDQUIT;
        }

        break;

      case 1:

        state = JUMPTOPAGE;
        buttons.get(s).get(i).setTyping(true);
        typing = "";
        buttons.get(s).get(i).setText("JUMP TO PAGE: " + typing);
        break;

      case 2:

        if (!saved)
          saveData();

        break;

      case 3:

        state = EDITINGSCRIPT;
        break;
      }

      break;

    case HIGHLIGHTINGEDIT:
    case ASSIGNINGEDIT:

      switch(i)
      {

      case 0:

        if (saved)
        {

          exit();
        } else
        {

          state = UNSAVEDQUIT;
        }

        break;

      case 1:

        //DEAL WITH THIS LATER
        state = JUMPTOPAGEEDIT;
        buttons.get(s).get(i).setTyping(true);
        typing = "";
        buttons.get(s).get(i).setText("JUMP TO PAGE: " + typing);
        break;

      case 2:

        if (!saved)
          saveData();

        break;
      }

      break;
    }


    //Check current state, then inside another switch to check which button has been clicked
    switch(s)
    {

    case MISSINGPAGE:

      switch(i)
      {

      case 0:

        if (saved)
        {

          exit();
        } else
        {

          state = UNSAVEDQUIT;
        }

        break;
      }

      break;

    case UNSAVEDQUIT:

      switch(i)
      {

      case 0:

        saveData();
        exit();
        break;

      case 1:

        exit();
        break;

      case 2:

        state = prevState;
        break;
      }

      break;

    case JUMPTOPAGE:

      switch(i)
      {

      case 0:

        if (saved)
        {

          exit();
        } else
        {

          state = UNSAVEDQUIT;
        }

        break;

      case 2:

        if (!saved)
          saveData();

        break;

      case 3:

        state = EDITINGSCRIPT;
        break;
      }

      break;

    case JUMPTOPAGEEDIT:

      switch(i)
      {

      case 0:

        if (saved)
        {

          exit();
        } else
        {

          state = UNSAVEDQUIT;
        }

        break;

      case 2:

        if (!saved)
          saveData();

        break;

      case 3:

        state = DISPLAYSCRIPT;
        break;

      case 4:

        editButton = true;
        break;
      }

      break;

    case ASSIGNINGNOTE:

      switch(i)
      {

      case 4:

        notes.add(new SkipNote(selectedLines, selected));
        saved = false;
        buttons.get(ASSIGNINGNOTE).clear();
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
        state = DISPLAYSCRIPT;
        break;

      case 5:

        notes.add(new ParaphraseNote(selectedLines, selected));
        buttons.get(ASSIGNINGNOTE).clear();
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
        typing = "";
        state = ASSIGNINGPPHRASE;
        break;

      case 6:

        notes.add(new CallForLineNote(selectedLines, selected));
        saved = false;
        buttons.get(ASSIGNINGNOTE).clear();
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
        state = DISPLAYSCRIPT;
        break;

      case 7:

        notes.add(new MissedCueNote(selectedLines, selected));
        saved = false;
        buttons.get(ASSIGNINGNOTE).clear();
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(0));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(1));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(2));
        buttons.get(ASSIGNINGNOTE).add(buttons.get(DISPLAYSCRIPT).get(3));
        state = DISPLAYSCRIPT;
        break;
      }

      break;

    case EDITINGSCRIPT:

      switch(i)
      {

      case 0:

        if (saved)
        {

          exit();
        } else
        {

          state = UNSAVEDQUIT;
        }

        break;

      case 1:

        state = JUMPTOPAGEEDIT;
        buttons.get(s).get(i).setTyping(true);
        typing = "";
        buttons.get(s).get(i).setText("JUMP TO PAGE: " + typing);
        break;

      case 2:

        if (!saved)
          saveData();

        break;

      case 3:

        state = DISPLAYSCRIPT;
        break;

      case 4:

        editButton = true;
        break;

      case 5:

        state = SEPARATELINE;
        break;
      }

      break;
    }

    prevState = s;
  }

  public void prepareMenu(float x, float y)
  {

    PVector tlp = new PVector();
    PVector brp = new PVector();

    //This should use textWidth() of the longest button option
    if (x + textWidth(Menu.LONGEST) + 2 * xMargin > width)
    {

      if (y + Menu.COUNT * textHeight > height)
      {

        tlp.set(x - 2 * xMargin - textWidth(Menu.LONGEST), y - Menu.COUNT * textHeight);
      } else
      {

        tlp.set(x - 2 * xMargin - textWidth(Menu.LONGEST), y);
      }
    } else
    {

      if (y + Menu.COUNT * textHeight > height)
      {

        tlp.set(x, y - Menu.COUNT * textHeight);
      } else
      {

        tlp.set(x, y);
      }
    }

    menu = new Menu(tlp, textWidth(Menu.LONGEST));

    for (Button button : menu.getButtons ())
    {

      buttons.get(ASSIGNINGNOTE).add(button);
    }
  }

  public void saveData()
  {

    String[] saveActors = new String[2 * actors.size()];
    int i = 0;

    for (Actor actor : actors)
    {

      saveActors[i] = actor.getCharName();
      saveActors[i + 1] = actor.getActorName();
      i += 2;
    }

    saveStrings(prefix + "/actors.txt", saveActors);
    int numWords = 0;
    int numLines = 0;

    for (Line line : lines)
    {

      numLines++;

      for (Word word : line.getWords ())
      {

        numWords++;
      }
    }

    String[] saveWords = new String[4 * numLines + 2 * numWords];
    i = 0;

    for (Line line : lines)
    {

      saveWords[i] = String.valueOf(actors.indexOf(line.getActor()));
      saveWords[i + 1] = String.valueOf(line.getPage());
      saveWords[i + 2] = line.getPos().toString();
      saveWords[i + 3] = String.valueOf(line.getWords().size());
      i += 4;

      for (Word word : line.getWords ())
      {

        saveWords[i] = word.getWord();
        saveWords[i + 1] = word.getPos().toString();
        i += 2;
      }
    }

    saveStrings(prefix + "/lines.txt", saveWords);
    String[] savePages = new String[2 * pages.size()];
    i = 0;

    for (Page page : pages)
    {

      savePages[i] = String.valueOf(page.getNumber());
      savePages[i + 1] = page.getPos().toString();
      i += 2;
    }

    saveStrings(prefix + "/pages.txt", savePages);

    int noteCount = 0;

    for (Note note : notes)
    {

      switch(note.getType())
      {

      case 0:
      case 2:
      case 3:

        noteCount += 4 + note.getActors().size() + 2 * note.getLines().size() + note.getWords().size();
        break;

      case 1:

        noteCount += 5 + note.getActors().size() + 2 * note.getLines().size() + note.getWords().size();
        break;
      }
    }

    String[] saveNotes = new String[noteCount];
    i = 0;

    for (Note note : notes)
    {

      switch(note.getType())
      {

      case 0:
      case 2:
      case 3:

        saveNotes[i] = String.valueOf(note.getType());
        saveNotes[i + 1] = String.valueOf(note.getActors().size());
        i += 2;

        for (Actor actor : note.getActors ())
        {

          saveNotes[i] = String.valueOf(actors.indexOf(actor));
          i++;
        }

        saveNotes[i] = String.valueOf(note.getLines().size());
        i++;

        for (Line line : note.getLines ())
        {

          saveNotes[i] = String.valueOf(lines.indexOf(line));
          i++;
          int wordCount = 0;

          for (Word word : note.getWords ())
          {

            if (line.getWords().indexOf(word) != -1)
              wordCount++;
          }

          saveNotes[i] = String.valueOf(wordCount);
          i++;

          for (Word word : note.getWords ())
          {

            if (line.getWords().indexOf(word) != -1)
            {

              saveNotes[i] = String.valueOf(line.getWords().indexOf(word));
              i++;
            }
          }
        }

        saveNotes[i] = String.valueOf(note.getRehearsal());
        i++;
        break;

      case 1:

        saveNotes[i] = String.valueOf(note.getType());
        saveNotes[i + 1] = String.valueOf(note.getActors().size());
        i += 2;

        for (Actor actor : note.getActors ())
        {

          saveNotes[i] = String.valueOf(actors.indexOf(actor));
          i++;
        }

        saveNotes[i] = String.valueOf(note.getLines().size());
        i++;

        for (Line line : note.getLines ())
        {

          saveNotes[i] = String.valueOf(lines.indexOf(line));
          i++;
          int wordCount = 0;

          for (Word word : note.getWords ())
          {

            if (line.getWords().indexOf(word) != -1)
              wordCount++;
          }

          saveNotes[i] = String.valueOf(wordCount);
          i++;

          for (Word word : note.getWords ())
          {

            if (line.getWords().indexOf(word) != -1)
            {

              saveNotes[i] = String.valueOf(line.getWords().indexOf(word));
              i++;
            }
          }
        }

        saveNotes[i] = note.getSaid();
        saveNotes[i + 1] = String.valueOf(note.getRehearsal());
        i += 2;
        break;
      }
    }

    saveStrings(prefix + "/savedNotes.txt", saveNotes);
    noteCount = currentRehearsal * (3 * actors.size() + 3);

    for (Note note : notes)
    {

      switch(note.getType())
      {

      case 0:
      case 2:
      case 3:

        noteCount += note.getActors().size() * (note.getLines().size() + 1);
        break;

      case 1:

        noteCount += note.getActors().size() * (note.getLines().size() + 2);
        break;
      }
    }

    for (int j = currentRehearsal; j >= 1; j--)
    {
      OutputStream allNotes;
      try
      {
        allNotes = new FileOutputStream(mkFile(prefix+"/ActorNotes/Rehearsal "+str(j)+"/AllNotes.txt"));
      }
      catch (Exception e) 
      {
        //die
        e.printStackTrace();
        continue;
      }

      for (Actor a : actors)
      {
        try
        {
          String name = "\n\n\n" + a.getCharName() + " (Played by " + ((a.getActorName()=="")?"...":a.getActorName() + ")\n\n");
          allNotes.write(name.getBytes());
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }
        OutputStream actorNotes;
        try
        {
          actorNotes = new FileOutputStream(mkFile(prefix+"/ActorNotes/Rehearsal "+str(j)+"/"+a.getCharName() + ((a.getActorName()=="")?"":"(" + a.getActorName() + ")" ) + ".txt"));
        }
        catch (Exception e) 
        {
          //die
          e.printStackTrace();
          continue;
        }
        for (Note n : a.getNotes ())
        {
          if (n.getRehearsal() == j)
          {
            try
            {
              byte[] t = n.toString().getBytes();
              actorNotes.write(t);
              allNotes.write(t);
            }
            catch (Exception e)
            {
              e.printStackTrace();
              continue;
            }
          }
        }
      }
    }
    println("YAY YOU SAVED!");
    saved = true;
  }

  public PVector vectorFromString(String s)
  {
    return(new PVector(Float.parseFloat(s.substring(2, s.indexOf(","))), Float.parseFloat(s.substring(s.indexOf(",") + 2, s.indexOf(",", s.indexOf(",") + 1)))));
  }

  public void exit()
  {
    set_script_null();
  }
}

class SkipNote extends Note
{
  
  //Constructors
  //Default Constructor
  SkipNote()
  {
    
    super();
    type = 0;
    
  }
  
  //Constructor given lines and words
  SkipNote(ArrayList<Line> ls, ArrayList<Word> ws)
  {
    
    super();
    lines.addAll(ls);
    words.addAll(ws);
    type = 0;
    
    for(Line line : lines)
    {
      
      if(actors.indexOf(line.getActor()) == -1)
        actors.add(line.getActor());
        
    }
    
    giveToActors();
    
  }
  
  public String toString()
  {
    String str = "SKIPPED LINE, PAGE "+str(lines.get(0).getPage())+"\n\tLINE:\n\t\t";
    
    for(Line l : lines)
    {
      for(Word w : l.getWords())
      {
        str += w.getWord() + " ";
      }
      str += "\n\t";
    }
    str += "ACTOR SKIPPED:\n\t";
    
    for(Word w : words)
    {
      str += w.getWord() + " ";
    }
    
    str += " ...\n\n";
    
    return str;
  }
  
}
class Word
{
  
  //Variable declarations
  protected String word;
  //posInLine describes the Word's position relative to the beginning of the line. 
  protected PVector posInLine;
  protected boolean highlighted;
  
  Word(String w)
  {
    
    word = w;
    posInLine = new PVector();
    highlighted = false;
    
  }
  
  Word(String w, PVector p)
  {
    
    word = w;
    posInLine = p;
    highlighted = false;
    
  }
  
  //Get and set word
  public String getWord()
  {
    
    return word;
    
  }
  
  public void setWord(String w)
  {
    
    word = w;
    
  }
  
  //Get and set posInLine
  public PVector getPos()
  {
    
    return posInLine;
    
  }
  
  public void setPos(float x, float y)
  {
    
    posInLine.set(x, y);
    
  }
  
  //Get and set highlighting
  public boolean isHighlighted()
  {
    
    return highlighted;
    
  }
  
  public void setHighlight(boolean h)
  {
    
    highlighted = h;
    
  }
  
  //toString
  public String toString()
  {
    
    return word;
    
  }
  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#FF0000", "Stage_Manager_2_8" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
